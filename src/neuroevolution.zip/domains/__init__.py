

__all__ = ['ne']