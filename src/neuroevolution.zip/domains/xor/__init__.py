

__all__ = ['xor_neat_feedforeward']