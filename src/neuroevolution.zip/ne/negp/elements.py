
from brain.elements import Neuron
from brain.elements import NeuralElement

class FeatureNeuronBox(NeuralElement):
    def __init__(self):
        self.connectId = ''
        self.neurons = []

class FeatureNeuron(Neuron):
    def __init__(self):
        pass



