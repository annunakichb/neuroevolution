
class EHNALRunner:
    def __init__(self):
        pass
    def activate(self,net,inputsac):
        # 取得输入
        inputNeurons = net.getInputNeurons()


    def doTest(self,net,task):
        '''
        执行测试
        :param net:  测试网络
        :param task: 测试任务
        :return: None
        '''




